'use client';

import { useState, useEffect, useCallback } from 'react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import HomePage from '@/components/HomePage';
import BlogPage from '@/components/BlogPage';
import ContactPage from '@/components/ContactPage';
import PasswordGenerator from '@/components/tools/PasswordGenerator';
import WordCounter from '@/components/tools/WordCounter';
import ImageCompressor from '@/components/tools/ImageCompressor';
import YouTubeThumbnail from '@/components/tools/YouTubeThumbnail';
import InstagramReel from '@/components/tools/InstagramReel';
import ImageToPdf from '@/components/tools/ImageToPdf';
import PdfToImage from '@/components/tools/PdfToImage';
import QrCodeGenerator from '@/components/tools/QrCodeGenerator';
import UrlShortener from '@/components/tools/UrlShortener';
import TextToSpeech from '@/components/tools/TextToSpeech';
import SpeechToText from '@/components/tools/SpeechToText';
import ImageResizer from '@/components/tools/ImageResizer';
import BackgroundRemover from '@/components/tools/BackgroundRemover';
import JsonFormatter from '@/components/tools/JsonFormatter';
import Base64Encoder from '@/components/tools/Base64Encoder';

function useHashRouter() {
  const [hash, setHash] = useState(
    typeof window !== 'undefined' ? window.location.hash || '#/' : '#/'
  );

  useEffect(() => {
    const handleHashChange = () => {
      setHash(window.location.hash || '#/');
    };
    window.addEventListener('hashchange', handleHashChange);
    return () => window.removeEventListener('hashchange', handleHashChange);
  }, []);

  const navigate = useCallback((newHash: string) => {
    window.location.hash = newHash;
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  return { hash, navigate };
}

function Router({ hash, navigate }: { hash: string; navigate: (h: string) => void }) {
  const route = hash || '#/';

  // Home
  if (route === '#/' || route === '#' || route === '') {
    return <HomePage onNavigate={navigate} />;
  }

  // Tool pages
  if (route === '#/tools/password-generator') {
    return <PasswordGenerator onNavigate={navigate} />;
  }
  if (route === '#/tools/word-counter') {
    return <WordCounter onNavigate={navigate} />;
  }
  if (route === '#/tools/image-compressor') {
    return <ImageCompressor onNavigate={navigate} />;
  }
  if (route === '#/tools/youtube-thumbnail') {
    return <YouTubeThumbnail onNavigate={navigate} />;
  }
  if (route === '#/tools/instagram-reel') {
    return <InstagramReel onNavigate={navigate} />;
  }
  if (route === '#/tools/image-to-pdf') {
    return <ImageToPdf onNavigate={navigate} />;
  }
  if (route === '#/tools/pdf-to-image') {
    return <PdfToImage onNavigate={navigate} />;
  }
  if (route === '#/tools/qr-code-generator') {
    return <QrCodeGenerator onNavigate={navigate} />;
  }
  if (route === '#/tools/url-shortener') {
    return <UrlShortener onNavigate={navigate} />;
  }
  if (route === '#/tools/text-to-speech') {
    return <TextToSpeech onNavigate={navigate} />;
  }
  if (route === '#/tools/speech-to-text') {
    return <SpeechToText onNavigate={navigate} />;
  }
  if (route === '#/tools/image-resizer') {
    return <ImageResizer onNavigate={navigate} />;
  }
  if (route === '#/tools/background-remover') {
    return <BackgroundRemover onNavigate={navigate} />;
  }
  if (route === '#/tools/json-formatter') {
    return <JsonFormatter onNavigate={navigate} />;
  }
  if (route === '#/tools/base64-encoder') {
    return <Base64Encoder onNavigate={navigate} />;
  }

  // Blog
  if (route === '#/blog') {
    return <BlogPage />;
  }

  // Contact
  if (route === '#/contact') {
    return <ContactPage />;
  }

  // 404
  return (
    <main className="min-h-screen pt-20 flex items-center justify-center">
      <div className="text-center px-4">
        <h1 className="text-8xl font-black gradient-text mb-4">404</h1>
        <p className="text-xl text-[#AAAAAA] mb-2 font-light">Page not found</p>
        <p className="text-sm text-[#555555] mb-10">
          The page you&apos;re looking for doesn&apos;t exist or has been moved.
        </p>
        <button
          onClick={() => navigate('#/')}
          className="cta-primary inline-flex items-center gap-2 px-8 py-4 rounded-xl text-white font-semibold text-sm"
        >
          Go Home
        </button>
      </div>
    </main>
  );
}

export default function Home() {
  const { hash, navigate } = useHashRouter();

  return (
    <div className="min-h-screen flex flex-col bg-black">
      <Header currentHash={hash} onNavigate={navigate} />
      <div className="flex-1">
        <Router hash={hash} navigate={navigate} />
      </div>
      <Footer onNavigate={navigate} />
    </div>
  );
}
