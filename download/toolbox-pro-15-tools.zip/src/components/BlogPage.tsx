'use client';

import { useState } from 'react';
import { BookOpen, Calendar, ArrowRight, Tag } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import AdPlaceholder from './AdPlaceholder';

interface BlogPost {
  id: number;
  title: string;
  excerpt: string;
  date: string;
  category: string;
  content: string;
}

const blogPosts: BlogPost[] = [
  {
    id: 1,
    title: 'Best Free Online Tools in 2026',
    excerpt:
      'Discover the top free online tools that can boost your productivity and make your life easier in 2026.',
    date: '2026-05-15',
    category: 'Guides',
    content: `The landscape of free online tools continues to evolve rapidly. In 2026, we have access to incredibly powerful browser-based tools that rival desktop applications.

## Top Picks for 2026

**1. Password Generators** - With cyber threats on the rise, using a strong password generator is more important than ever. Modern generators use crypto.getRandomValues() for maximum security.

**2. Image Compression Tools** - Browser-based image compressors have gotten remarkably good, often achieving 60-70% file size reduction with minimal quality loss using the Canvas API.

**3. Text Analysis Tools** - Word counters and text analyzers now offer real-time statistics including reading time, complexity scores, and SEO recommendations.

**4. YouTube Thumbnail Downloaders** - These tools make it easy to grab high-resolution thumbnails for design reference or content creation.

**5. SEO Analyzers** - Free SEO tools can scan your pages and provide actionable recommendations for improving search rankings.

The best part? All of these tools run entirely in your browser, meaning your data stays private and secure. No servers, no signups, no downloads required.

As we move forward, expect to see more AI-powered features integrated into these tools, making them even more powerful and intuitive.`,
  },
  {
    id: 2,
    title: 'How to Compress Images Without Losing Quality',
    excerpt:
      'Learn the best techniques for image compression that maintain visual quality while dramatically reducing file sizes.',
    date: '2026-04-28',
    category: 'Tutorials',
    content: `Image compression is essential for web performance, but doing it right means balancing file size with visual quality. Here's how to do it effectively.

## Understanding Compression Types

**Lossy Compression** reduces file size by permanently eliminating certain data, especially redundant information. JPEG is the most common lossy format.

**Lossless Compression** reduces file size without losing any data. PNG uses lossless compression, but file sizes are typically larger.

## Best Practices

1. **Choose the right format**: Use JPEG for photographs and WebP for web graphics. WebP offers both lossy and lossless compression with smaller file sizes than JPEG and PNG.

2. **Adjust quality wisely**: A quality setting of 75-85% for JPEG typically produces excellent results with significantly reduced file sizes.

3. **Resize before compressing**: Don't upload a 4000px image when 1200px will do. Resize first, then compress.

4. **Use progressive JPEG**: Progressive JPEGs load in layers, giving users a low-quality preview quickly.

## Browser-Based Compression

Modern browser tools use the HTML5 Canvas API to compress images client-side. This means:
- Your images never leave your device
- Processing is instant
- No server upload required
- Complete privacy

Try our Image Compressor tool to see these techniques in action!`,
  },
  {
    id: 3,
    title: 'The Ultimate Guide to Strong Passwords',
    excerpt:
      'Protect your accounts with these password security tips and learn why password strength matters more than ever.',
    date: '2026-04-10',
    category: 'Security',
    content: `In an era of increasing cyber threats, password security is your first line of defense. Here's everything you need to know about creating and maintaining strong passwords.

## Why Password Strength Matters

A 6-character password with only lowercase letters can be cracked in under 10 minutes. A 16-character password with mixed character types would take billions of years to crack through brute force.

## Characteristics of a Strong Password

- **Length**: At least 12 characters, preferably 16+
- **Complexity**: Mix of uppercase, lowercase, numbers, and symbols
- **Uniqueness**: Different for every account
- **Randomness**: Not based on personal information or dictionary words

## Common Mistakes

1. **Reusing passwords** - If one account is breached, all accounts with the same password are compromised
2. **Using personal information** - Birthdays, pet names, and addresses are easy to guess
3. **Short passwords** - Even complex short passwords can be cracked quickly
4. **Sequential patterns** - "123456", "qwerty", "abcdef" are in every cracking dictionary

## The Solution: Password Managers + Generators

Use a password generator (like our free tool) to create unique, random passwords for each account. Store them in a reputable password manager so you only need to remember one master password.

Start generating secure passwords today with our Password Generator tool!`,
  },
  {
    id: 4,
    title: 'YouTube Thumbnail Best Practices for Content Creators',
    excerpt:
      'Create eye-catching thumbnails that drive clicks and grow your channel with these proven design strategies.',
    date: '2026-03-22',
    category: 'Content Creation',
    content: `Your YouTube thumbnail is often the first impression potential viewers have of your content. Here's how to make it count.

## Why Thumbnails Matter

Studies show that 90% of the best-performing YouTube videos use custom thumbnails. A compelling thumbnail can increase click-through rates by 30-50%.

## Design Best Practices

1. **Use high-contrast colors**: Bright, contrasting colors stand out in YouTube's interface. Complementary color pairs work well.

2. **Include expressive faces**: Close-up faces with strong emotions (surprise, excitement) attract more clicks.

3. **Keep text minimal**: 3-5 words maximum. Text should be large enough to read on mobile screens.

4. **Maintain consistency**: Use a consistent style across your thumbnails to build brand recognition.

5. **Use the right dimensions**: 1280x720 pixels is the recommended resolution. Always use a 16:9 aspect ratio.

## Technical Requirements

- Minimum resolution: 640x360 pixels
- Recommended resolution: 1280x720 pixels  
- File size: Under 2MB
- Formats: JPG, GIF, BMP, or PNG

## Tools for Creating Thumbnails

Use our YouTube Thumbnail Downloader to study what works for successful channels in your niche. Download their thumbnails for design inspiration and reverse-engineer their strategies.

Remember: the best thumbnail is one that accurately represents your content while being impossible to scroll past.`,
  },
  {
    id: 5,
    title: 'Word Count Matters: How to Write for the Web',
    excerpt:
      'Understanding the ideal word count for different content types and why it matters for SEO and engagement.',
    date: '2026-03-05',
    category: 'Writing',
    content: `Word count isn't just a number—it's a strategic consideration that affects SEO, reader engagement, and content effectiveness.

## Ideal Word Counts by Content Type

- **Blog posts**: 1,500-2,500 words for comprehensive guides
- **Product pages**: 300-500 words for descriptions
- **Social media posts**: 40-80 characters for maximum engagement
- **Email newsletters**: 200-500 words
- **Landing pages**: 500-1,000 words
- **White papers**: 3,000-5,000 words

## The SEO Connection

Long-form content (1,500+ words) tends to rank higher in search results. However, quality always trumps quantity. Google's algorithms reward content that:
- Thoroughly answers the user's question
- Provides unique value
- Is well-structured and easy to read
- Includes relevant keywords naturally

## Reading Time Matters

Average reading speed is about 200-250 words per minute. Always consider how long your content will take to read. Online readers have shorter attention spans, so:
- Use headers to break up text
- Include bullet points and lists
- Keep paragraphs short (3-4 sentences)
- Add images and visual elements

Use our Word Counter tool to track your word count and estimate reading time in real-time!`,
  },
  {
    id: 6,
    title: '10 Essential Browser Tools Everyone Should Know',
    excerpt:
      'These free browser-based tools can save you hours of work and boost your productivity without installing anything.',
    date: '2026-02-18',
    category: 'Productivity',
    content: `You don't need to install expensive software to be productive. These free browser-based tools can handle most everyday tasks.

## The Top 10

**1. Password Generators** - Create unbreakable passwords in seconds without installing anything.

**2. Word Counters** - Essential for writers, students, and content creators who need to track word counts and reading time.

**3. Image Compressors** - Reduce image file sizes for faster website loading and easier sharing.

**4. Color Pickers** - Extract colors from any website or image for design projects.

**5. JSON Formatters** - Clean up and validate JSON data instantly.

**6. Base64 Encoders/Decoders** - Convert data between formats for web development.

**7. CSS Generators** - Create gradients, shadows, and other CSS properties visually.

**8. QR Code Generators** - Create QR codes for URLs, text, or contact information.

**9. YouTube Thumbnail Downloaders** - Grab high-res thumbnails for design reference.

**10. Text Diff Checkers** - Compare two pieces of text to find differences.

## Why Browser-Based Tools Win

- **No installation required** - Works on any device with a browser
- **Always up to date** - No software updates to manage
- **Privacy focused** - Many process data locally, never sending it to servers
- **Cross-platform** - Works on Windows, Mac, Linux, and mobile

All of these tools and more are available for free right here on ToolBox Pro!`,
  },
];

const categoryColors: Record<string, string> = {
  Guides: 'bg-purple-500/10 text-purple-400 border-purple-500/20',
  Tutorials: 'bg-cyan-500/10 text-cyan-400 border-cyan-500/20',
  Security: 'bg-green-500/10 text-green-400 border-green-500/20',
  'Content Creation': 'bg-red-500/10 text-red-400 border-red-500/20',
  Writing: 'bg-yellow-500/10 text-yellow-400 border-yellow-500/20',
  Productivity: 'bg-pink-500/10 text-pink-400 border-pink-500/20',
};

export default function BlogPage() {
  const [selectedPost, setSelectedPost] = useState<BlogPost | null>(null);

  return (
    <main className="min-h-screen pt-20 pb-12">
      <div className="mx-auto max-w-5xl px-4 sm:px-6 lg:px-8 pt-8">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="inline-flex h-14 w-14 items-center justify-center rounded-2xl bg-[#8A2BE2]/10 border border-[#8A2BE2]/20 mb-5">
            <BookOpen className="h-7 w-7 text-[#8A2BE2]" />
          </div>
          <h1 className="text-3xl sm:text-5xl font-black text-white mb-4 tracking-tight">
            Blog & <span className="gradient-text">Guides</span>
          </h1>
          <p className="text-[#AAAAAA] max-w-lg mx-auto text-base">
            Tips, tutorials, and insights to help you make the most of free online tools.
          </p>
        </div>

        {/* Blog Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {blogPosts.map((post, index) => (
            <article
              key={post.id}
              className={`tool-card p-6 cursor-pointer ${
                index === 2 ? 'md:col-span-2' : ''
              }`}
              onClick={() => setSelectedPost(post)}
            >
              <div className="flex items-center gap-3 mb-4">
                <Badge
                  variant="outline"
                  className={`text-[10px] ${
                    categoryColors[post.category] || 'bg-[#8A2BE2]/10 text-[#8A2BE2] border-[#8A2BE2]/20'
                  }`}
                >
                  <Tag className="h-2.5 w-2.5 mr-1" />
                  {post.category}
                </Badge>
                <span className="flex items-center gap-1 text-xs text-[#555555]">
                  <Calendar className="h-3 w-3" />
                  {new Date(post.date).toLocaleDateString('en-US', {
                    month: 'short',
                    day: 'numeric',
                    year: 'numeric',
                  })}
                </span>
              </div>
              <h2 className="text-lg font-bold text-white mb-2 group-hover:text-[#8A2BE2] transition-colors">
                {post.title}
              </h2>
              <p className="text-sm text-[#888888] leading-relaxed mb-4">
                {post.excerpt}
              </p>
              <span className="inline-flex items-center gap-1.5 text-sm font-semibold text-[#8A2BE2]">
                Read More
                <ArrowRight className="h-3.5 w-3.5" />
              </span>
            </article>
          ))}
        </div>

        {/* Ad between rows */}
        <div className="my-14">
          <AdPlaceholder size="banner" />
        </div>
      </div>

      {/* Blog Post Dialog */}
      <Dialog
        open={!!selectedPost}
        onOpenChange={(open) => !open && setSelectedPost(null)}
      >
        <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto bg-[#111111] border-[#222222]">
          <DialogHeader>
            <div className="flex items-center gap-3 mb-2">
              <Badge
                variant="outline"
                className={`text-[10px] ${
                  categoryColors[selectedPost?.category || ''] || 'bg-[#8A2BE2]/10 text-[#8A2BE2] border-[#8A2BE2]/20'
                }`}
              >
                {selectedPost?.category}
              </Badge>
              <span className="text-xs text-[#555555]">
                {selectedPost?.date &&
                  new Date(selectedPost.date).toLocaleDateString('en-US', {
                    month: 'long',
                    day: 'numeric',
                    year: 'numeric',
                  })}
              </span>
            </div>
            <DialogTitle className="text-xl font-bold text-white">
              {selectedPost?.title}
            </DialogTitle>
          </DialogHeader>
          <div className="prose prose-invert prose-sm max-w-none text-[#AAAAAA] leading-relaxed">
            {selectedPost?.content.split('\n').map((paragraph, i) => {
              if (paragraph.startsWith('## ')) {
                return (
                  <h2
                    key={i}
                    className="text-lg font-bold text-white mt-6 mb-3"
                  >
                    {paragraph.replace('## ', '')}
                  </h2>
                );
              }
              if (paragraph.startsWith('**') && paragraph.endsWith('**')) {
                return (
                  <p key={i} className="font-semibold text-white mt-3">
                    {paragraph.replace(/\*\*/g, '')}
                  </p>
                );
              }
              if (paragraph.startsWith('- ')) {
                return (
                  <li key={i} className="ml-4">
                    {paragraph.replace('- ', '')}
                  </li>
                );
              }
              if (paragraph.match(/^\d+\./)) {
                return (
                  <li key={i} className="ml-4 list-decimal">
                    {paragraph.replace(/^\d+\.\s*/, '').replace(/\*\*/g, '')}
                  </li>
                );
              }
              if (paragraph.trim() === '') {
                return <br key={i} />;
              }
              return (
                <p key={i} className="my-2">
                  {paragraph}
                </p>
              );
            })}
          </div>
        </DialogContent>
      </Dialog>
    </main>
  );
}
